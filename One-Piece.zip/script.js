

let menu = document.querySelector('#wrap');

document.querySelector('#toggle').onclick = function(){
   menu.classList.toggle('dark-mod');
}